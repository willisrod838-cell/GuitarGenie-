# GuitarGenie APK Build Instructions

This document provides complete instructions for building the GuitarGenie Android APK.

## Prerequisites

### Option 1: Build Locally (Recommended)

1. **Install Java Development Kit (JDK)**
   - Download and install JDK 11 or later from [oracle.com](https://www.oracle.com/java/technologies/downloads/)
   - Set `JAVA_HOME` environment variable

2. **Install Android SDK**
   - Download Android Studio from [developer.android.com](https://developer.android.com/studio)
   - Install Android SDK API Level 36 (or higher)
   - Set `ANDROID_HOME` environment variable to your Android SDK location

3. **Install Node.js and npm**
   - Download from [nodejs.org](https://nodejs.org/)
   - Verify: `node --version` and `npm --version`

4. **Install Cordova**
   ```bash
   npm install -g cordova
   ```

### Option 2: Use Cloud Build Services

- **GitHub Actions** - Free CI/CD with Android build support
- **Codemagic** - Specialized mobile app CI/CD
- **Firebase App Distribution** - Google's app distribution platform
- **EAS Build** - Expo's build service (supports React Native)

## Building the APK

### Step 1: Set Environment Variables

```bash
# On macOS/Linux
export JAVA_HOME=/path/to/jdk
export ANDROID_HOME=/path/to/android/sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools

# On Windows
set JAVA_HOME=C:\path\to\jdk
set ANDROID_HOME=C:\path\to\android\sdk
set PATH=%PATH%;%ANDROID_HOME%\tools;%ANDROID_HOME%\platform-tools
```

### Step 2: Navigate to Project Directory

```bash
cd guitargenie-cordova
```

### Step 3: Build Debug APK (for testing)

```bash
cordova build android
```

The debug APK will be located at:
```
platforms/android/app/build/outputs/apk/debug/app-debug.apk
```

### Step 4: Build Release APK (for distribution)

```bash
cordova build android --release
```

The release APK will be located at:
```
platforms/android/app/build/outputs/apk/release/app-release-unsigned.apk
```

### Step 5: Sign the Release APK

Create a keystore file (do this only once):
```bash
keytool -genkey -v -keystore guitargenie.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias guitargenie
```

Sign the APK:
```bash
jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore guitargenie.keystore platforms/android/app/build/outputs/apk/release/app-release-unsigned.apk guitargenie
```

Optimize the signed APK:
```bash
zipalign -v 4 platforms/android/app/build/outputs/apk/release/app-release-unsigned.apk GuitarGenie.apk
```

## Installation

### On Your Device

1. **Enable Unknown Sources**
   - Go to Settings > Security > Unknown Sources
   - Enable installation from unknown sources

2. **Transfer APK to Device**
   - Connect device via USB
   - Copy `GuitarGenie.apk` to device storage

3. **Install**
   - Open file manager on device
   - Locate and tap `GuitarGenie.apk`
   - Follow installation prompts

### Using ADB (Android Debug Bridge)

```bash
adb install GuitarGenie.apk
```

## Distribution

### Google Play Store

1. Create a Google Play Developer account ($25 one-time fee)
2. Create app listing
3. Upload signed APK
4. Fill in app details, screenshots, description
5. Submit for review

### Alternative Distribution

- **GitHub Releases** - Host APK on GitHub
- **APKMirror** - Third-party app repository
- **F-Droid** - Open-source app repository
- **Direct distribution** - Share APK link directly

## Troubleshooting

### "ANDROID_HOME not found"
```bash
# Verify Android SDK location
ls $ANDROID_HOME/platforms
```

### "Gradle build failed"
```bash
# Clean and rebuild
cordova clean android
cordova build android
```

### "Java version mismatch"
```bash
# Verify Java version
java -version
# Should be 11 or higher
```

### "Insufficient permissions"
```bash
# On Linux, you may need to add user to android group
sudo usermod -a -G android $USER
```

## Project Structure

```
guitargenie-cordova/
├── www/                      # Web application files
│   ├── index.html           # Main application
│   ├── css/                 # Stylesheets
│   └── js/                  # JavaScript
├── config.xml               # Cordova configuration
├── platforms/
│   └── android/             # Android platform
├── plugins/                 # Cordova plugins
└── package.json             # Dependencies
```

## Key Features

- **Real Audio Recording** - Web Audio API with microphone access
- **48kHz Sample Rate** - Studio-quality audio
- **24-bit Depth** - Professional audio quality
- **MP3/WebM Format** - Compatible with all devices
- **Waveform Visualization** - Real-time audio display
- **Recording Library** - Save and manage recordings
- **Playback Controls** - Play, download, delete recordings
- **Offline Support** - Works without internet connection

## Permissions

The app requires the following Android permissions:

- `RECORD_AUDIO` - To access microphone
- `MODIFY_AUDIO_SETTINGS` - To control audio settings
- `WRITE_EXTERNAL_STORAGE` - To save recordings
- `READ_EXTERNAL_STORAGE` - To access saved files
- `INTERNET` - For future cloud features
- `ACCESS_NETWORK_STATE` - To check connectivity

## Support

For issues or questions:
1. Check the [Cordova documentation](https://cordova.apache.org/)
2. Review [Android development guide](https://developer.android.com/guide)
3. Check project GitHub issues

## Version Information

- **Cordova Version**: 15.0.0
- **Android Target SDK**: 36
- **Minimum SDK**: 24 (Android 7.0)
- **Node.js**: 14.0 or higher
- **Java**: JDK 11 or higher

## Next Steps

1. Set up your development environment
2. Follow the build instructions above
3. Test on Android device or emulator
4. Sign and optimize for distribution
5. Publish to app store or distribute directly
